<?php

/* @Framework/Form/submit_widget.html.php */
class __TwigTemplate_3b38c53585a9102acd42e98aff9cd85331e845ab913e405bd565b97b6b545b16 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fc74cc3481ec70878d635bb788b62f57e0fbe18a016d5f8fc99ec5d2ed862f17 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fc74cc3481ec70878d635bb788b62f57e0fbe18a016d5f8fc99ec5d2ed862f17->enter($__internal_fc74cc3481ec70878d635bb788b62f57e0fbe18a016d5f8fc99ec5d2ed862f17_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'submit')) ?>
";
        
        $__internal_fc74cc3481ec70878d635bb788b62f57e0fbe18a016d5f8fc99ec5d2ed862f17->leave($__internal_fc74cc3481ec70878d635bb788b62f57e0fbe18a016d5f8fc99ec5d2ed862f17_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/submit_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'submit')) ?>
";
    }
}
