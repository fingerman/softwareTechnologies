<?php

/* :security:register.html.twig */
class __TwigTemplate_0e27f1465a0780dd60a4b3d3237398c7906f22c834e8ef9f408ff9ff274d026f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8b32aad7112b7199e68a8b78f9b522e91c6c1d0d66788155e06cd45b191c843c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8b32aad7112b7199e68a8b78f9b522e91c6c1d0d66788155e06cd45b191c843c->enter($__internal_8b32aad7112b7199e68a8b78f9b522e91c6c1d0d66788155e06cd45b191c843c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":security:register.html.twig"));

        // line 1
        echo "
<form method=\"post\" name=\"register\">
    <input type=\"text\" name=\"user[email]\" >
    <input type=\"text\" name=\"user[fullName]\" >
    <input type=\"text\" name=\"user[password]\" >
    <input type=\"hidden\" name=\"_csrf_token\" value=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderCsrfToken("register"), "html", null, true);
        echo "\">
    <input type=\"submit\">
</form>



";
        
        $__internal_8b32aad7112b7199e68a8b78f9b522e91c6c1d0d66788155e06cd45b191c843c->leave($__internal_8b32aad7112b7199e68a8b78f9b522e91c6c1d0d66788155e06cd45b191c843c_prof);

    }

    public function getTemplateName()
    {
        return ":security:register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  29 => 6,  22 => 1,);
    }

    public function getSource()
    {
        return "
<form method=\"post\" name=\"register\">
    <input type=\"text\" name=\"user[email]\" >
    <input type=\"text\" name=\"user[fullName]\" >
    <input type=\"text\" name=\"user[password]\" >
    <input type=\"hidden\" name=\"_csrf_token\" value=\"{{ csrf_token('register') }}\">
    <input type=\"submit\">
</form>



";
    }
}
