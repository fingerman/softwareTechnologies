<?php

/* @Framework/Form/form_row.html.php */
class __TwigTemplate_4be60ae3c320079d0dc8aafa22a3940901ea9b396868ba59645c3b81c79afc0d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e2e3c498f0f051caa6d7f12ab24eb5628083cb790c41c328a6ab0a68ae3ffe4f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e2e3c498f0f051caa6d7f12ab24eb5628083cb790c41c328a6ab0a68ae3ffe4f->enter($__internal_e2e3c498f0f051caa6d7f12ab24eb5628083cb790c41c328a6ab0a68ae3ffe4f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_e2e3c498f0f051caa6d7f12ab24eb5628083cb790c41c328a6ab0a68ae3ffe4f->leave($__internal_e2e3c498f0f051caa6d7f12ab24eb5628083cb790c41c328a6ab0a68ae3ffe4f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
    }
}
