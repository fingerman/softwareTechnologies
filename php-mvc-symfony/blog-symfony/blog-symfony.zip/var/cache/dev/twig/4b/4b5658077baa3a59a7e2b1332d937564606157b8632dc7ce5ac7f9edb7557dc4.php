<?php

/* @WebProfiler/Profiler/toolbar_redirect.html.twig */
class __TwigTemplate_3ee025d12c116e75301dddee15bf82573358ed495e292aac463c04fba53e738b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@WebProfiler/Profiler/toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0b46c89aebc994a943dcdfa4329efd7aa3827ee31549b4f3cc96271920858e1f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0b46c89aebc994a943dcdfa4329efd7aa3827ee31549b4f3cc96271920858e1f->enter($__internal_0b46c89aebc994a943dcdfa4329efd7aa3827ee31549b4f3cc96271920858e1f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0b46c89aebc994a943dcdfa4329efd7aa3827ee31549b4f3cc96271920858e1f->leave($__internal_0b46c89aebc994a943dcdfa4329efd7aa3827ee31549b4f3cc96271920858e1f_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_0d1837894494d4828b4f118cc62a983318dbd6c842dc61afb9a2b393bec49dc2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0d1837894494d4828b4f118cc62a983318dbd6c842dc61afb9a2b393bec49dc2->enter($__internal_0d1837894494d4828b4f118cc62a983318dbd6c842dc61afb9a2b393bec49dc2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_0d1837894494d4828b4f118cc62a983318dbd6c842dc61afb9a2b393bec49dc2->leave($__internal_0d1837894494d4828b4f118cc62a983318dbd6c842dc61afb9a2b393bec49dc2_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_61a991ce236d8df0e90eaf6a2d5a000dddda7abb6ef967bbd4a1570458d46079 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_61a991ce236d8df0e90eaf6a2d5a000dddda7abb6ef967bbd4a1570458d46079->enter($__internal_61a991ce236d8df0e90eaf6a2d5a000dddda7abb6ef967bbd4a1570458d46079_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_61a991ce236d8df0e90eaf6a2d5a000dddda7abb6ef967bbd4a1570458d46079->leave($__internal_61a991ce236d8df0e90eaf6a2d5a000dddda7abb6ef967bbd4a1570458d46079_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 8,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
";
    }
}
