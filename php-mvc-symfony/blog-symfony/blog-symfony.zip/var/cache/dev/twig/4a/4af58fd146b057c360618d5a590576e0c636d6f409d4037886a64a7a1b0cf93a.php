<?php

/* @Twig/Exception/exception.atom.twig */
class __TwigTemplate_f1d34a7bd68d65498cd2a002736744a5ad6f504367c724845f48e1ddb2a015bd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5b7e77d41a2116872f59c90d907ead44b3bef45437695f8f08aa52a04dd34d49 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5b7e77d41a2116872f59c90d907ead44b3bef45437695f8f08aa52a04dd34d49->enter($__internal_5b7e77d41a2116872f59c90d907ead44b3bef45437695f8f08aa52a04dd34d49_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "@Twig/Exception/exception.atom.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_5b7e77d41a2116872f59c90d907ead44b3bef45437695f8f08aa52a04dd34d49->leave($__internal_5b7e77d41a2116872f59c90d907ead44b3bef45437695f8f08aa52a04dd34d49_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "{% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}
";
    }
}
