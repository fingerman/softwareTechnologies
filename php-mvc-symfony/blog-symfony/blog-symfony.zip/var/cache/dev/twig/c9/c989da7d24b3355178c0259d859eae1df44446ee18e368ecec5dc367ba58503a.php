<?php

/* @Framework/Form/money_widget.html.php */
class __TwigTemplate_4ed4a6b96879bef3b5b73a2ae41881e8f53d4eabbcd3cdc25ffdd43fea2c4d7a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2607f7050b52670f488e33e12389da5991e49b92e68eba950c387ef4ad19458c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2607f7050b52670f488e33e12389da5991e49b92e68eba950c387ef4ad19458c->enter($__internal_2607f7050b52670f488e33e12389da5991e49b92e68eba950c387ef4ad19458c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/money_widget.html.php"));

        // line 1
        echo "<?php echo str_replace('";
        echo twig_escape_filter($this->env, (isset($context["widget"]) ? $context["widget"] : $this->getContext($context, "widget")), "html", null, true);
        echo "', \$view['form']->block(\$form, 'form_widget_simple'), \$money_pattern) ?>
";
        
        $__internal_2607f7050b52670f488e33e12389da5991e49b92e68eba950c387ef4ad19458c->leave($__internal_2607f7050b52670f488e33e12389da5991e49b92e68eba950c387ef4ad19458c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/money_widget.html.php";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo str_replace('{{ widget }}', \$view['form']->block(\$form, 'form_widget_simple'), \$money_pattern) ?>
";
    }
}
