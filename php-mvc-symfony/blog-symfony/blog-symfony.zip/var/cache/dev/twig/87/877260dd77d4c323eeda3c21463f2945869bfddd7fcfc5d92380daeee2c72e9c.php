<?php

/* @Framework/Form/form_errors.html.php */
class __TwigTemplate_63ef6308699eb5745db61660ab4de1489486fe3973d52af8ec47c4a47af145ea extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_703cced19060dbe4ff4a07d95972273fbc9005c004a181c8ce3ce65145028b42 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_703cced19060dbe4ff4a07d95972273fbc9005c004a181c8ce3ce65145028b42->enter($__internal_703cced19060dbe4ff4a07d95972273fbc9005c004a181c8ce3ce65145028b42_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        // line 1
        echo "<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
";
        
        $__internal_703cced19060dbe4ff4a07d95972273fbc9005c004a181c8ce3ce65145028b42->leave($__internal_703cced19060dbe4ff4a07d95972273fbc9005c004a181c8ce3ce65145028b42_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_errors.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
";
    }
}
