<?php

/* @Framework/Form/form_end.html.php */
class __TwigTemplate_ff5957c58144724e877b41f75496817464c5ead30a4f829f34c54f882c795837 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4e2a9ec5e66601b7d69374e041f3bcf233bf3874cec84e01ccf0faeec73e93a5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4e2a9ec5e66601b7d69374e041f3bcf233bf3874cec84e01ccf0faeec73e93a5->enter($__internal_4e2a9ec5e66601b7d69374e041f3bcf233bf3874cec84e01ccf0faeec73e93a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        // line 1
        echo "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
        
        $__internal_4e2a9ec5e66601b7d69374e041f3bcf233bf3874cec84e01ccf0faeec73e93a5->leave($__internal_4e2a9ec5e66601b7d69374e041f3bcf233bf3874cec84e01ccf0faeec73e93a5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_end.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
    }
}
