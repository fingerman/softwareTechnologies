<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_67cbebd63ea534c019eefcb0b45276a91a479d876fbcf883ead86b17e3974543 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dfc20730134b22bbff71a60657051f9b5d7759191bb6a28116dc97f3ba84fc7b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dfc20730134b22bbff71a60657051f9b5d7759191bb6a28116dc97f3ba84fc7b->enter($__internal_dfc20730134b22bbff71a60657051f9b5d7759191bb6a28116dc97f3ba84fc7b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_dfc20730134b22bbff71a60657051f9b5d7759191bb6a28116dc97f3ba84fc7b->leave($__internal_dfc20730134b22bbff71a60657051f9b5d7759191bb6a28116dc97f3ba84fc7b_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_bfd105818d7d56908cf655a6a4f8256d7980f181f1c42e1bd1480ff404b0a57b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bfd105818d7d56908cf655a6a4f8256d7980f181f1c42e1bd1480ff404b0a57b->enter($__internal_bfd105818d7d56908cf655a6a4f8256d7980f181f1c42e1bd1480ff404b0a57b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_bfd105818d7d56908cf655a6a4f8256d7980f181f1c42e1bd1480ff404b0a57b->leave($__internal_bfd105818d7d56908cf655a6a4f8256d7980f181f1c42e1bd1480ff404b0a57b_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_93d42e2925deec558564174740924a5750441b593a03c6a742b903a6a7940796 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_93d42e2925deec558564174740924a5750441b593a03c6a742b903a6a7940796->enter($__internal_93d42e2925deec558564174740924a5750441b593a03c6a742b903a6a7940796_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_93d42e2925deec558564174740924a5750441b593a03c6a742b903a6a7940796->leave($__internal_93d42e2925deec558564174740924a5750441b593a03c6a742b903a6a7940796_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_a9c6603ef905f23dd81307191b8be7476d2020ce9193549647ddef30b421ab1b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a9c6603ef905f23dd81307191b8be7476d2020ce9193549647ddef30b421ab1b->enter($__internal_a9c6603ef905f23dd81307191b8be7476d2020ce9193549647ddef30b421ab1b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_a9c6603ef905f23dd81307191b8be7476d2020ce9193549647ddef30b421ab1b->leave($__internal_a9c6603ef905f23dd81307191b8be7476d2020ce9193549647ddef30b421ab1b_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
";
    }
}
