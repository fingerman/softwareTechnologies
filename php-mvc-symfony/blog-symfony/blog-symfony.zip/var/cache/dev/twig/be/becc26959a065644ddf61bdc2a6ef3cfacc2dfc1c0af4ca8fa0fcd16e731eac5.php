<?php

/* @Framework/Form/form.html.php */
class __TwigTemplate_da8a2cbd2fbf15c92964cb445146eb9c9aed65bc83f58eb2ada107b219d86f6f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7e34de100d29d8a97430af2c06822acac16331d5e7bffeee5fffb95bd70e205e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7e34de100d29d8a97430af2c06822acac16331d5e7bffeee5fffb95bd70e205e->enter($__internal_7e34de100d29d8a97430af2c06822acac16331d5e7bffeee5fffb95bd70e205e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        // line 1
        echo "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
        
        $__internal_7e34de100d29d8a97430af2c06822acac16331d5e7bffeee5fffb95bd70e205e->leave($__internal_7e34de100d29d8a97430af2c06822acac16331d5e7bffeee5fffb95bd70e205e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
    }
}
