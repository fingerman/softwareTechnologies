<?php

/* TwigBundle:Exception:exception.css.twig */
class __TwigTemplate_867d01c1d23f9ce7e2dd506c662298ef84fc8e8391b219da3a0004e86cf52f4d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8aff1991c2594863bf82d2629faaffb02b0e5962d397f4dab658d25b60decc0e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8aff1991c2594863bf82d2629faaffb02b0e5962d397f4dab658d25b60decc0e->enter($__internal_8aff1991c2594863bf82d2629faaffb02b0e5962d397f4dab658d25b60decc0e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "TwigBundle:Exception:exception.css.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_8aff1991c2594863bf82d2629faaffb02b0e5962d397f4dab658d25b60decc0e->leave($__internal_8aff1991c2594863bf82d2629faaffb02b0e5962d397f4dab658d25b60decc0e_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 3,  25 => 2,  22 => 1,);
    }

    public function getSource()
    {
        return "/*
{% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}
*/
";
    }
}
