<?php

/* TwigBundle:Exception:error.json.twig */
class __TwigTemplate_633b12ad4bf0b2f69064dfee6c290bcffe892f47f8eeeadd0fb7761e9e3b1074 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c7047c8c9d74b6fae95f265410e81b8806eee0b2ab934e582c12ac52fcd87e79 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c7047c8c9d74b6fae95f265410e81b8806eee0b2ab934e582c12ac52fcd87e79->enter($__internal_c7047c8c9d74b6fae95f265410e81b8806eee0b2ab934e582c12ac52fcd87e79_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_c7047c8c9d74b6fae95f265410e81b8806eee0b2ab934e582c12ac52fcd87e79->leave($__internal_c7047c8c9d74b6fae95f265410e81b8806eee0b2ab934e582c12ac52fcd87e79_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "{{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}
";
    }
}
