<?php

/* TwigBundle:Exception:error.css.twig */
class __TwigTemplate_04e80977e93b755dbb049aa38d7300460187f8835111f073a0435ba6a5addd1a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_baf51c64ccad4edd1c16d1aa73c40c83477f157a1e7004666b63a5e1b44ba33e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_baf51c64ccad4edd1c16d1aa73c40c83477f157a1e7004666b63a5e1b44ba33e->enter($__internal_baf51c64ccad4edd1c16d1aa73c40c83477f157a1e7004666b63a5e1b44ba33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "css", null, true);
        echo "

*/
";
        
        $__internal_baf51c64ccad4edd1c16d1aa73c40c83477f157a1e7004666b63a5e1b44ba33e->leave($__internal_baf51c64ccad4edd1c16d1aa73c40c83477f157a1e7004666b63a5e1b44ba33e_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 2,  22 => 1,);
    }

    public function getSource()
    {
        return "/*
{{ status_code }} {{ status_text }}

*/
";
    }
}
