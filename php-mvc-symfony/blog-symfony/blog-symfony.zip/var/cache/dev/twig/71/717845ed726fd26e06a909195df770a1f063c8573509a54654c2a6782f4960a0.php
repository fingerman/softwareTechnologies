<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_d8b04f324fab3c4211506c934f315ca0b13cd249b69ac0963f1ec1bf8f56034d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_54ada9d05296ea1825cbeb3e753e3dc43fe93f2f1ea2064755660dd971e511a1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_54ada9d05296ea1825cbeb3e753e3dc43fe93f2f1ea2064755660dd971e511a1->enter($__internal_54ada9d05296ea1825cbeb3e753e3dc43fe93f2f1ea2064755660dd971e511a1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_54ada9d05296ea1825cbeb3e753e3dc43fe93f2f1ea2064755660dd971e511a1->leave($__internal_54ada9d05296ea1825cbeb3e753e3dc43fe93f2f1ea2064755660dd971e511a1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
    }
}
