<?php

/* @Framework/Form/form_rest.html.php */
class __TwigTemplate_e2f4d6c89780e3cc722fa95f56b9ee15998a2fc0b286ba09e7efcf4267a145ec extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_954fecdd7e8b7650f4beeacedd6abc77c7623af1a4d41eca5d57eb51c9ec879e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_954fecdd7e8b7650f4beeacedd6abc77c7623af1a4d41eca5d57eb51c9ec879e->enter($__internal_954fecdd7e8b7650f4beeacedd6abc77c7623af1a4d41eca5d57eb51c9ec879e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
";
        
        $__internal_954fecdd7e8b7650f4beeacedd6abc77c7623af1a4d41eca5d57eb51c9ec879e->leave($__internal_954fecdd7e8b7650f4beeacedd6abc77c7623af1a4d41eca5d57eb51c9ec879e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rest.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
";
    }
}
