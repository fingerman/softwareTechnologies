<?php

/* @Twig/Exception/error.json.twig */
class __TwigTemplate_007978243c3ff18b204547a9b2b4e78f10d4e80e1b057c65b93f37a5e83ef9c1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_635e7546c8ff24444e09c1a5e4e9ec26781a3940e85209fa66412fe26df87265 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_635e7546c8ff24444e09c1a5e4e9ec26781a3940e85209fa66412fe26df87265->enter($__internal_635e7546c8ff24444e09c1a5e4e9ec26781a3940e85209fa66412fe26df87265_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_635e7546c8ff24444e09c1a5e4e9ec26781a3940e85209fa66412fe26df87265->leave($__internal_635e7546c8ff24444e09c1a5e4e9ec26781a3940e85209fa66412fe26df87265_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "{{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}
";
    }
}
