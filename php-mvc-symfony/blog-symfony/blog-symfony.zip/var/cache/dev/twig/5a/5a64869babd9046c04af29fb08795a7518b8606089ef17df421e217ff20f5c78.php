<?php

/* WebProfilerBundle:Collector:router.html.twig */
class __TwigTemplate_795564a539db072fc58f72e4d4248302f97043bc8cb7d0488a4d932a79cd6054 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "WebProfilerBundle:Collector:router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bc094ccae8bb69ef80884dae7a077643366fa2995fbfc3cfb513f3856726cf1e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bc094ccae8bb69ef80884dae7a077643366fa2995fbfc3cfb513f3856726cf1e->enter($__internal_bc094ccae8bb69ef80884dae7a077643366fa2995fbfc3cfb513f3856726cf1e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_bc094ccae8bb69ef80884dae7a077643366fa2995fbfc3cfb513f3856726cf1e->leave($__internal_bc094ccae8bb69ef80884dae7a077643366fa2995fbfc3cfb513f3856726cf1e_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_0b5d6c1ad52bc3de2e5b497f8555530a05300a7f6cb49690f796e23b66476343 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0b5d6c1ad52bc3de2e5b497f8555530a05300a7f6cb49690f796e23b66476343->enter($__internal_0b5d6c1ad52bc3de2e5b497f8555530a05300a7f6cb49690f796e23b66476343_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_0b5d6c1ad52bc3de2e5b497f8555530a05300a7f6cb49690f796e23b66476343->leave($__internal_0b5d6c1ad52bc3de2e5b497f8555530a05300a7f6cb49690f796e23b66476343_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_0d7a54bfeccb84c03bb8d0444e07df3ac9d28f4a8e58e99fad8249e967e158ea = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0d7a54bfeccb84c03bb8d0444e07df3ac9d28f4a8e58e99fad8249e967e158ea->enter($__internal_0d7a54bfeccb84c03bb8d0444e07df3ac9d28f4a8e58e99fad8249e967e158ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_0d7a54bfeccb84c03bb8d0444e07df3ac9d28f4a8e58e99fad8249e967e158ea->leave($__internal_0d7a54bfeccb84c03bb8d0444e07df3ac9d28f4a8e58e99fad8249e967e158ea_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_926a69a83d9d6a74f144e78dac7c5bb98897f228c2625ce4c435f6585e3ce700 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_926a69a83d9d6a74f144e78dac7c5bb98897f228c2625ce4c435f6585e3ce700->enter($__internal_926a69a83d9d6a74f144e78dac7c5bb98897f228c2625ce4c435f6585e3ce700_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_926a69a83d9d6a74f144e78dac7c5bb98897f228c2625ce4c435f6585e3ce700->leave($__internal_926a69a83d9d6a74f144e78dac7c5bb98897f228c2625ce4c435f6585e3ce700_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Collector:router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
";
    }
}
