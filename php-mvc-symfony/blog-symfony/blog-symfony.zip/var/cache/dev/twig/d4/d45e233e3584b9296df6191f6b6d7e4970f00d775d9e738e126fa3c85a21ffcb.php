<?php

/* @WebProfiler/Profiler/ajax_layout.html.twig */
class __TwigTemplate_0111cbe1d49362e4c94934e9b39ec8aa89af9acc163322a5351743c5b9dbcb75 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_af3626228a9e3811b7f54a9a77315794b464588b82670eedd52c4701d544e4a1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_af3626228a9e3811b7f54a9a77315794b464588b82670eedd52c4701d544e4a1->enter($__internal_af3626228a9e3811b7f54a9a77315794b464588b82670eedd52c4701d544e4a1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_af3626228a9e3811b7f54a9a77315794b464588b82670eedd52c4701d544e4a1->leave($__internal_af3626228a9e3811b7f54a9a77315794b464588b82670eedd52c4701d544e4a1_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_ccc23dfbf34e8e96998178b3d096e2230633adf8951c58a85761b4e4971c7ea7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ccc23dfbf34e8e96998178b3d096e2230633adf8951c58a85761b4e4971c7ea7->enter($__internal_ccc23dfbf34e8e96998178b3d096e2230633adf8951c58a85761b4e4971c7ea7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_ccc23dfbf34e8e96998178b3d096e2230633adf8951c58a85761b4e4971c7ea7->leave($__internal_ccc23dfbf34e8e96998178b3d096e2230633adf8951c58a85761b4e4971c7ea7_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    public function getSource()
    {
        return "{% block panel '' %}
";
    }
}
