<?php

/* @Framework/Form/percent_widget.html.php */
class __TwigTemplate_e8c3b864e4bf819e63790cadecf9ceb796d9888a86dad8b39e9f8f01546f6bfe extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1627b44d2ab8045784cd7583f25587cce480a168002d5042c1f2f47950623b70 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1627b44d2ab8045784cd7583f25587cce480a168002d5042c1f2f47950623b70->enter($__internal_1627b44d2ab8045784cd7583f25587cce480a168002d5042c1f2f47950623b70_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?> %
";
        
        $__internal_1627b44d2ab8045784cd7583f25587cce480a168002d5042c1f2f47950623b70->leave($__internal_1627b44d2ab8045784cd7583f25587cce480a168002d5042c1f2f47950623b70_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/percent_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?> %
";
    }
}
