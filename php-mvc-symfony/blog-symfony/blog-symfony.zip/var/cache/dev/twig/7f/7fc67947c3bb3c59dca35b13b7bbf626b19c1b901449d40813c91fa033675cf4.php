<?php

/* @Framework/Form/url_widget.html.php */
class __TwigTemplate_994feb510216503ef084efcd4adf276551e2a35423991fb8c28b67304f078504 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_78445255436ce0f46c025ef511bcaff31741210192fbc4e8c0c247f32231fa34 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_78445255436ce0f46c025ef511bcaff31741210192fbc4e8c0c247f32231fa34->enter($__internal_78445255436ce0f46c025ef511bcaff31741210192fbc4e8c0c247f32231fa34_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'url')) ?>
";
        
        $__internal_78445255436ce0f46c025ef511bcaff31741210192fbc4e8c0c247f32231fa34->leave($__internal_78445255436ce0f46c025ef511bcaff31741210192fbc4e8c0c247f32231fa34_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/url_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'url')) ?>
";
    }
}
