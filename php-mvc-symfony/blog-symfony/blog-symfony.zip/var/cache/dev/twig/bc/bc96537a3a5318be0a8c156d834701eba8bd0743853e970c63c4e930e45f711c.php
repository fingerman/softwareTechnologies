<?php

/* @Framework/Form/form_widget.html.php */
class __TwigTemplate_a50aa2be95c04f4b547c52b3623f3a0438fbedcedbe501921d62959cc6a23dff extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d3b6ad38d46c65d5ac951e1635b1e44c6da80646bc77175f5b2c86348aea6fe6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d3b6ad38d46c65d5ac951e1635b1e44c6da80646bc77175f5b2c86348aea6fe6->enter($__internal_d3b6ad38d46c65d5ac951e1635b1e44c6da80646bc77175f5b2c86348aea6fe6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        // line 1
        echo "<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
";
        
        $__internal_d3b6ad38d46c65d5ac951e1635b1e44c6da80646bc77175f5b2c86348aea6fe6->leave($__internal_d3b6ad38d46c65d5ac951e1635b1e44c6da80646bc77175f5b2c86348aea6fe6_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
";
    }
}
