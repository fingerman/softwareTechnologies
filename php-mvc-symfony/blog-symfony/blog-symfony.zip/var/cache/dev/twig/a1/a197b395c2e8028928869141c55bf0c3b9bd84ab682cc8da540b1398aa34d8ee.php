<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_89dbd8d36127d4e284755d566acd258512c7b687c0cf9f1d59495b942629696d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c55c3479d5d9c1b2eadef596caa9eb9f14a0ad476941971ee2cc128fe742cffe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c55c3479d5d9c1b2eadef596caa9eb9f14a0ad476941971ee2cc128fe742cffe->enter($__internal_c55c3479d5d9c1b2eadef596caa9eb9f14a0ad476941971ee2cc128fe742cffe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_c55c3479d5d9c1b2eadef596caa9eb9f14a0ad476941971ee2cc128fe742cffe->leave($__internal_c55c3479d5d9c1b2eadef596caa9eb9f14a0ad476941971ee2cc128fe742cffe_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
    }
}
