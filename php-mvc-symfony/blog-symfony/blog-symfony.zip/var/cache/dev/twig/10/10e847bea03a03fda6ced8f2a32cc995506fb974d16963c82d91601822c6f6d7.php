<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_1e0161e8f7c3c7a32d7e26872ebd8aa152b0cf651bde899b439cc0d3db88f539 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_58b0dc63efa3071deb8fc94f285e56c9b6ecc1555f80715181e3a8997339a65b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_58b0dc63efa3071deb8fc94f285e56c9b6ecc1555f80715181e3a8997339a65b->enter($__internal_58b0dc63efa3071deb8fc94f285e56c9b6ecc1555f80715181e3a8997339a65b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_58b0dc63efa3071deb8fc94f285e56c9b6ecc1555f80715181e3a8997339a65b->leave($__internal_58b0dc63efa3071deb8fc94f285e56c9b6ecc1555f80715181e3a8997339a65b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
    }
}
