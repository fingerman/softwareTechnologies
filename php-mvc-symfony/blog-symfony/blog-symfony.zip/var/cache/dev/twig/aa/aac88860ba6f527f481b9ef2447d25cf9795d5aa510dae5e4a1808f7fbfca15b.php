<?php

/* @Framework/Form/range_widget.html.php */
class __TwigTemplate_6cb3d6a841ec64c6fa124ecf6001bf412b56782d47326400280573f1b3c0155d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6212d89ef31b5d7830cf546b385d8a7783b2511eeca120b498a4ea92186880bb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6212d89ef31b5d7830cf546b385d8a7783b2511eeca120b498a4ea92186880bb->enter($__internal_6212d89ef31b5d7830cf546b385d8a7783b2511eeca120b498a4ea92186880bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/range_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'range'));
";
        
        $__internal_6212d89ef31b5d7830cf546b385d8a7783b2511eeca120b498a4ea92186880bb->leave($__internal_6212d89ef31b5d7830cf546b385d8a7783b2511eeca120b498a4ea92186880bb_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/range_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'range'));
";
    }
}
