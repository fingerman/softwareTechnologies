<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_6cbdbb27bf4ab02ce385c294dcdb219a4033c29a1590dac7ee10560748c066e1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ffd3017e472868de72c3739c8c7696371848e6d2aceb6e7815e1b607ee90c51b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ffd3017e472868de72c3739c8c7696371848e6d2aceb6e7815e1b607ee90c51b->enter($__internal_ffd3017e472868de72c3739c8c7696371848e6d2aceb6e7815e1b607ee90c51b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_ffd3017e472868de72c3739c8c7696371848e6d2aceb6e7815e1b607ee90c51b->leave($__internal_ffd3017e472868de72c3739c8c7696371848e6d2aceb6e7815e1b607ee90c51b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
    }
}
