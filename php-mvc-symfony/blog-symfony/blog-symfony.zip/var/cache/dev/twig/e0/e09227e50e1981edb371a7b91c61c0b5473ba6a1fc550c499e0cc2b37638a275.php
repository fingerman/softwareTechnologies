<?php

/* @Framework/Form/form_widget_simple.html.php */
class __TwigTemplate_6c88cf5d61f93f295721eda6213de82975efa7b093204f14bf45fa1afcc50824 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_63bd8220c76f5f2c85ebdabd4ae8fedd233a4cc5e2871e3f33b365e8497c48a6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_63bd8220c76f5f2c85ebdabd4ae8fedd233a4cc5e2871e3f33b365e8497c48a6->enter($__internal_63bd8220c76f5f2c85ebdabd4ae8fedd233a4cc5e2871e3f33b365e8497c48a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        // line 1
        echo "<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
";
        
        $__internal_63bd8220c76f5f2c85ebdabd4ae8fedd233a4cc5e2871e3f33b365e8497c48a6->leave($__internal_63bd8220c76f5f2c85ebdabd4ae8fedd233a4cc5e2871e3f33b365e8497c48a6_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_simple.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
";
    }
}
