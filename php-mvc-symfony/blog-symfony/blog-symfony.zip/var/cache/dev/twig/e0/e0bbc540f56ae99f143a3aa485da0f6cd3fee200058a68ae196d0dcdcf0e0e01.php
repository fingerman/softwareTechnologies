<?php

/* @Framework/Form/attributes.html.php */
class __TwigTemplate_35a6f4385aee0cccd43beb29a25264d47711919823d731e586f63de4e560f8e0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_de10d58a43b965705cf6e77bb89b2eb1305ae7cf82b4be14052a5215326ed37e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_de10d58a43b965705cf6e77bb89b2eb1305ae7cf82b4be14052a5215326ed37e->enter($__internal_de10d58a43b965705cf6e77bb89b2eb1305ae7cf82b4be14052a5215326ed37e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
";
        
        $__internal_de10d58a43b965705cf6e77bb89b2eb1305ae7cf82b4be14052a5215326ed37e->leave($__internal_de10d58a43b965705cf6e77bb89b2eb1305ae7cf82b4be14052a5215326ed37e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
";
    }
}
