<?php

/* @Framework/FormTable/form_row.html.php */
class __TwigTemplate_ccad20c9ce9f17cb4479c5d56e98a513ac4617baa5b7932577e2abb921fe9749 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_67e9a463e8cb4a46c61eff6c98e6273700d2c6b8216c08e0429dc38bea34126c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_67e9a463e8cb4a46c61eff6c98e6273700d2c6b8216c08e0429dc38bea34126c->enter($__internal_67e9a463e8cb4a46c61eff6c98e6273700d2c6b8216c08e0429dc38bea34126c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        // line 1
        echo "<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_67e9a463e8cb4a46c61eff6c98e6273700d2c6b8216c08e0429dc38bea34126c->leave($__internal_67e9a463e8cb4a46c61eff6c98e6273700d2c6b8216c08e0429dc38bea34126c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
    }
}
