<?php

/* @Twig/Exception/exception.json.twig */
class __TwigTemplate_2d5ae21363785783d67946d6468a1547296bf2d3aebcea05f63ce4ced26a0c66 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0e3958473ff7769bea26d03a603db4b16970e14bde6f37b57bb2d2813e264e52 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0e3958473ff7769bea26d03a603db4b16970e14bde6f37b57bb2d2813e264e52->enter($__internal_0e3958473ff7769bea26d03a603db4b16970e14bde6f37b57bb2d2813e264e52_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "exception" => $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "toarray", array()))));
        echo "
";
        
        $__internal_0e3958473ff7769bea26d03a603db4b16970e14bde6f37b57bb2d2813e264e52->leave($__internal_0e3958473ff7769bea26d03a603db4b16970e14bde6f37b57bb2d2813e264e52_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "{{ { 'error': { 'code': status_code, 'message': status_text, 'exception': exception.toarray } }|json_encode|raw }}
";
    }
}
