<?php

/* @Twig/Exception/error.css.twig */
class __TwigTemplate_1fbb5fd5692c804e6e1297f960594d32cff0321b709508f1cc48e18a4c8e16b9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_672c52a6534aa24a458042976c9b9355dc4053192f597855b169f9388ca4134b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_672c52a6534aa24a458042976c9b9355dc4053192f597855b169f9388ca4134b->enter($__internal_672c52a6534aa24a458042976c9b9355dc4053192f597855b169f9388ca4134b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "css", null, true);
        echo "

*/
";
        
        $__internal_672c52a6534aa24a458042976c9b9355dc4053192f597855b169f9388ca4134b->leave($__internal_672c52a6534aa24a458042976c9b9355dc4053192f597855b169f9388ca4134b_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 2,  22 => 1,);
    }

    public function getSource()
    {
        return "/*
{{ status_code }} {{ status_text }}

*/
";
    }
}
