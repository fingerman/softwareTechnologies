<?php

/* @Framework/Form/number_widget.html.php */
class __TwigTemplate_e2e29dd5dce64efa0f51353edde4e0f186e6cc68812c8c95fb12f7eaa3cd95e6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3dbec76fe4629516790eca3e4541656f48760a17084c4dfef333975f40f39490 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3dbec76fe4629516790eca3e4541656f48760a17084c4dfef333975f40f39490->enter($__internal_3dbec76fe4629516790eca3e4541656f48760a17084c4dfef333975f40f39490_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?>
";
        
        $__internal_3dbec76fe4629516790eca3e4541656f48760a17084c4dfef333975f40f39490->leave($__internal_3dbec76fe4629516790eca3e4541656f48760a17084c4dfef333975f40f39490_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/number_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?>
";
    }
}
