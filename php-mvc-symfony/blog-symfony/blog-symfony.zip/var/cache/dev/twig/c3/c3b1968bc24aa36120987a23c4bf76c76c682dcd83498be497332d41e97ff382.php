<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_bfe5e3c12c4015d189278879687b2137e18ab022c4c73498c5175b880eda68a7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6385115c3d419d0042feb59d1c66204ae58429254d40e9f551e1e4fad915b055 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6385115c3d419d0042feb59d1c66204ae58429254d40e9f551e1e4fad915b055->enter($__internal_6385115c3d419d0042feb59d1c66204ae58429254d40e9f551e1e4fad915b055_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_6385115c3d419d0042feb59d1c66204ae58429254d40e9f551e1e4fad915b055->leave($__internal_6385115c3d419d0042feb59d1c66204ae58429254d40e9f551e1e4fad915b055_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_d2dffdd00a9f769616ea8204fd2de90ad30c305b95fb88e25331d5f64e21d056 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d2dffdd00a9f769616ea8204fd2de90ad30c305b95fb88e25331d5f64e21d056->enter($__internal_d2dffdd00a9f769616ea8204fd2de90ad30c305b95fb88e25331d5f64e21d056_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_d2dffdd00a9f769616ea8204fd2de90ad30c305b95fb88e25331d5f64e21d056->leave($__internal_d2dffdd00a9f769616ea8204fd2de90ad30c305b95fb88e25331d5f64e21d056_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    public function getSource()
    {
        return "{% block panel '' %}
";
    }
}
