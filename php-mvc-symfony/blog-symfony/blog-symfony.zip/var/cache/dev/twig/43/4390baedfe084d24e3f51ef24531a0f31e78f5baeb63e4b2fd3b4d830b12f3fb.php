<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_0d74f539a17b145db727e8f4ce4c3cf3ddf513848967439bb3892628db421d01 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6814556a340b86518aaecc778f475e56b3192e76fed82d874011a7cd6710dabb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6814556a340b86518aaecc778f475e56b3192e76fed82d874011a7cd6710dabb->enter($__internal_6814556a340b86518aaecc778f475e56b3192e76fed82d874011a7cd6710dabb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.rdf.twig", 1)->display($context);
        
        $__internal_6814556a340b86518aaecc778f475e56b3192e76fed82d874011a7cd6710dabb->leave($__internal_6814556a340b86518aaecc778f475e56b3192e76fed82d874011a7cd6710dabb_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "{% include '@Twig/Exception/error.xml.twig' %}
";
    }
}
