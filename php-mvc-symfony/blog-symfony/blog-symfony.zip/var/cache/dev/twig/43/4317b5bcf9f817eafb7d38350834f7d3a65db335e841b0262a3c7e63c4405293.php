<?php

/* @Framework/Form/form_rows.html.php */
class __TwigTemplate_fa6f3a1973d0a5269f0d7b016cd17cc4e1e273e7c5713f45b67d2c76ac966d89 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ccdc20a41f6cff657b56de25affb4ec22addf8ee0d2cf2bbd04721cf9006409f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ccdc20a41f6cff657b56de25affb4ec22addf8ee0d2cf2bbd04721cf9006409f->enter($__internal_ccdc20a41f6cff657b56de25affb4ec22addf8ee0d2cf2bbd04721cf9006409f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
";
        
        $__internal_ccdc20a41f6cff657b56de25affb4ec22addf8ee0d2cf2bbd04721cf9006409f->leave($__internal_ccdc20a41f6cff657b56de25affb4ec22addf8ee0d2cf2bbd04721cf9006409f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rows.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
";
    }
}
