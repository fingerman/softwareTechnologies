<?php

/* @Framework/Form/radio_widget.html.php */
class __TwigTemplate_4931b0c5dc8105aaee105e35825be38c7d28e2df453e5edbf5eb82e511442105 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b8c00e55cca079fb8257161341990cd3fd389d26829eef985d96da538633d6e1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b8c00e55cca079fb8257161341990cd3fd389d26829eef985d96da538633d6e1->enter($__internal_b8c00e55cca079fb8257161341990cd3fd389d26829eef985d96da538633d6e1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        // line 1
        echo "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_b8c00e55cca079fb8257161341990cd3fd389d26829eef985d96da538633d6e1->leave($__internal_b8c00e55cca079fb8257161341990cd3fd389d26829eef985d96da538633d6e1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/radio_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
    }
}
