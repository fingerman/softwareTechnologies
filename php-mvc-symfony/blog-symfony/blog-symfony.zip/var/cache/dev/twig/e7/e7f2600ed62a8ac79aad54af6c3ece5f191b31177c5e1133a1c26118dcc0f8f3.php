<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_311f29bbe7cd95a7130cac320761fe884f6d7bbdb3dfa5e8c58704fcc1c46aea extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_670d7703f9a78470c929cab754afd4bdcc02a039834d1e5c66eb2a1bd74ec9cf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_670d7703f9a78470c929cab754afd4bdcc02a039834d1e5c66eb2a1bd74ec9cf->enter($__internal_670d7703f9a78470c929cab754afd4bdcc02a039834d1e5c66eb2a1bd74ec9cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_670d7703f9a78470c929cab754afd4bdcc02a039834d1e5c66eb2a1bd74ec9cf->leave($__internal_670d7703f9a78470c929cab754afd4bdcc02a039834d1e5c66eb2a1bd74ec9cf_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'search')) ?>
";
    }
}
