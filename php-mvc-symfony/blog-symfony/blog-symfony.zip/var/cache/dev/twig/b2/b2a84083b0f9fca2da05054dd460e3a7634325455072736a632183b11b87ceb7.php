<?php

/* @Framework/Form/collection_widget.html.php */
class __TwigTemplate_b25988debd9c49e8494c1cb1de04c132421132dcf261ea5f9798fba9c27a4779 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_11e469bf1ed7a460197c60b02d9db2f2c4b557c1fbb5acf0adb46c958c94a758 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_11e469bf1ed7a460197c60b02d9db2f2c4b557c1fbb5acf0adb46c958c94a758->enter($__internal_11e469bf1ed7a460197c60b02d9db2f2c4b557c1fbb5acf0adb46c958c94a758_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        // line 1
        echo "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
        
        $__internal_11e469bf1ed7a460197c60b02d9db2f2c4b557c1fbb5acf0adb46c958c94a758->leave($__internal_11e469bf1ed7a460197c60b02d9db2f2c4b557c1fbb5acf0adb46c958c94a758_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/collection_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
    }
}
