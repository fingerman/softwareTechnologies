<?php

/* @Framework/FormTable/hidden_row.html.php */
class __TwigTemplate_f9d97fa66c270b11b560be551029f465ca235f62cacd01e152d15ef8874e22a0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fb254acf43837915c31c52e4bd29e15181e50a36328218fc820da21d89a1370b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fb254acf43837915c31c52e4bd29e15181e50a36328218fc820da21d89a1370b->enter($__internal_fb254acf43837915c31c52e4bd29e15181e50a36328218fc820da21d89a1370b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        // line 1
        echo "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_fb254acf43837915c31c52e4bd29e15181e50a36328218fc820da21d89a1370b->leave($__internal_fb254acf43837915c31c52e4bd29e15181e50a36328218fc820da21d89a1370b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
    }
}
