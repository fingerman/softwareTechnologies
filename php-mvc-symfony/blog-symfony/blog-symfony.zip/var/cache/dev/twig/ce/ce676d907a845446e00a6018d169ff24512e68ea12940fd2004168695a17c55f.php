<?php

/* @Framework/Form/hidden_widget.html.php */
class __TwigTemplate_b64e5665c7d580985780096d2ba9c563df12d9b5f26739669d1197505de4bb65 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5e5fef422da2c9f8f3cbba7a9596c914c1ba58767bdfe19d4b4a583b8b8dcf75 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5e5fef422da2c9f8f3cbba7a9596c914c1ba58767bdfe19d4b4a583b8b8dcf75->enter($__internal_5e5fef422da2c9f8f3cbba7a9596c914c1ba58767bdfe19d4b4a583b8b8dcf75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
";
        
        $__internal_5e5fef422da2c9f8f3cbba7a9596c914c1ba58767bdfe19d4b4a583b8b8dcf75->leave($__internal_5e5fef422da2c9f8f3cbba7a9596c914c1ba58767bdfe19d4b4a583b8b8dcf75_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
";
    }
}
