<?php

/* @Framework/Form/checkbox_widget.html.php */
class __TwigTemplate_cd82348996732bd7b7ba39e90aece5b5ecafb5954ead708b0dd67740bb2bdfaa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7493caf203a54a429f44b24cda6788fb6ebff02364b8ca4836736952e3d6cb39 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7493caf203a54a429f44b24cda6788fb6ebff02364b8ca4836736952e3d6cb39->enter($__internal_7493caf203a54a429f44b24cda6788fb6ebff02364b8ca4836736952e3d6cb39_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        // line 1
        echo "<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_7493caf203a54a429f44b24cda6788fb6ebff02364b8ca4836736952e3d6cb39->leave($__internal_7493caf203a54a429f44b24cda6788fb6ebff02364b8ca4836736952e3d6cb39_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/checkbox_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
    }
}
