<?php

/* TwigBundle:Exception:exception.rdf.twig */
class __TwigTemplate_0ca51dcc3e7ca8240a18fd114bc4d0a76886af3fd2cf4f09a752d9e61b7ca355 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_05adfd99169f96bc89589ad1cf904811a8b8b879fe7112ad687cd5e52a567df1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_05adfd99169f96bc89589ad1cf904811a8b8b879fe7112ad687cd5e52a567df1->enter($__internal_05adfd99169f96bc89589ad1cf904811a8b8b879fe7112ad687cd5e52a567df1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "TwigBundle:Exception:exception.rdf.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_05adfd99169f96bc89589ad1cf904811a8b8b879fe7112ad687cd5e52a567df1->leave($__internal_05adfd99169f96bc89589ad1cf904811a8b8b879fe7112ad687cd5e52a567df1_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "{% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}
";
    }
}
