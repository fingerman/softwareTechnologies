<?php

/* @Twig/Exception/error.atom.twig */
class __TwigTemplate_fe05859467d8d438b679cfea4b3a40d23ea5823c02638b8f0e5170bf1d7e7a3c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4c08b7683edd4c03171edf4575a1c4221c1ebb5b6184ed77dddf9f8cf131b605 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4c08b7683edd4c03171edf4575a1c4221c1ebb5b6184ed77dddf9f8cf131b605->enter($__internal_4c08b7683edd4c03171edf4575a1c4221c1ebb5b6184ed77dddf9f8cf131b605_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "@Twig/Exception/error.atom.twig", 1)->display($context);
        
        $__internal_4c08b7683edd4c03171edf4575a1c4221c1ebb5b6184ed77dddf9f8cf131b605->leave($__internal_4c08b7683edd4c03171edf4575a1c4221c1ebb5b6184ed77dddf9f8cf131b605_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "{% include '@Twig/Exception/error.xml.twig' %}
";
    }
}
