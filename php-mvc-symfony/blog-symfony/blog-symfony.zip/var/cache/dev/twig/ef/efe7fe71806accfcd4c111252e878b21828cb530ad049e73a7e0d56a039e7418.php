<?php

/* @Framework/Form/choice_widget_expanded.html.php */
class __TwigTemplate_512c4c1ac58b2fb5ccfa6984e0755f1d0947eef4f5f870106b7ba3c4788fd660 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_eb8e6c4bcafc9d79f058a0ce1d85e9becd50fca757b2f35407902f83170d032b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eb8e6c4bcafc9d79f058a0ce1d85e9becd50fca757b2f35407902f83170d032b->enter($__internal_eb8e6c4bcafc9d79f058a0ce1d85e9becd50fca757b2f35407902f83170d032b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
";
        
        $__internal_eb8e6c4bcafc9d79f058a0ce1d85e9becd50fca757b2f35407902f83170d032b->leave($__internal_eb8e6c4bcafc9d79f058a0ce1d85e9becd50fca757b2f35407902f83170d032b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget_expanded.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
";
    }
}
