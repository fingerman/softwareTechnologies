<?php

/* :user:profile.html.twig */
class __TwigTemplate_204c23cb5834457ec0827a9b69cd591ae767a5bc1972642ad334f5bfd22c6f64 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":user:profile.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_73da647706361ae1756828f25af0d9b8505af4efb3b1d8938f6615e2290fccaa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_73da647706361ae1756828f25af0d9b8505af4efb3b1d8938f6615e2290fccaa->enter($__internal_73da647706361ae1756828f25af0d9b8505af4efb3b1d8938f6615e2290fccaa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":user:profile.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_73da647706361ae1756828f25af0d9b8505af4efb3b1d8938f6615e2290fccaa->leave($__internal_73da647706361ae1756828f25af0d9b8505af4efb3b1d8938f6615e2290fccaa_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_8e790d61eefc993c26c631d71f4c57364ebfd7214ffdd845851396dc9158ab7f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8e790d61eefc993c26c631d71f4c57364ebfd7214ffdd845851396dc9158ab7f->enter($__internal_8e790d61eefc993c26c631d71f4c57364ebfd7214ffdd845851396dc9158ab7f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "profile";
        
        $__internal_8e790d61eefc993c26c631d71f4c57364ebfd7214ffdd845851396dc9158ab7f->leave($__internal_8e790d61eefc993c26c631d71f4c57364ebfd7214ffdd845851396dc9158ab7f_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_b234ca4b35f7b76835d5dcf95908d4c57f21f7f9e486787e712e1e4461a41bc2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b234ca4b35f7b76835d5dcf95908d4c57f21f7f9e486787e712e1e4461a41bc2->enter($__internal_b234ca4b35f7b76835d5dcf95908d4c57f21f7f9e486787e712e1e4461a41bc2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <div>
        ";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "email", array()), "html", null, true);
        echo "
        <br>
        ";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "fullName", array()), "html", null, true);
        echo "
    </div>
";
        
        $__internal_b234ca4b35f7b76835d5dcf95908d4c57f21f7f9e486787e712e1e4461a41bc2->leave($__internal_b234ca4b35f7b76835d5dcf95908d4c57f21f7f9e486787e712e1e4461a41bc2_prof);

    }

    public function getTemplateName()
    {
        return ":user:profile.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  61 => 9,  56 => 7,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends 'base.html.twig' %}

{% block body_id 'profile' %}

{% block main %}
    <div>
        {{ user.email }}
        <br>
        {{ user.fullName }}
    </div>
{% endblock %}
";
    }
}
