<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_392d1e8926595ee1ad4f29114adec9d105cf1092a77bf408b484c808bcf6327d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_312f3213ddd7d78db601fb54c98580a728db6e579c54c375bba8ae902673756f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_312f3213ddd7d78db601fb54c98580a728db6e579c54c375bba8ae902673756f->enter($__internal_312f3213ddd7d78db601fb54c98580a728db6e579c54c375bba8ae902673756f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_312f3213ddd7d78db601fb54c98580a728db6e579c54c375bba8ae902673756f->leave($__internal_312f3213ddd7d78db601fb54c98580a728db6e579c54c375bba8ae902673756f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->widget(\$form) ?>
";
    }
}
