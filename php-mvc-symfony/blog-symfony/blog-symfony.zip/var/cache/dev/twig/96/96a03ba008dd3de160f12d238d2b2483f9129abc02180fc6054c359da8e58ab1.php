<?php

/* @Twig/Exception/error.rdf.twig */
class __TwigTemplate_9e8c3d35d6493030a4f77ce33481426d036ce3dec82e8f582cd444365ca24238 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_adf4c3223cef5a1e40e467baf47a683b4a01b633869c6aa33e19b197278ae914 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_adf4c3223cef5a1e40e467baf47a683b4a01b633869c6aa33e19b197278ae914->enter($__internal_adf4c3223cef5a1e40e467baf47a683b4a01b633869c6aa33e19b197278ae914_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "@Twig/Exception/error.rdf.twig", 1)->display($context);
        
        $__internal_adf4c3223cef5a1e40e467baf47a683b4a01b633869c6aa33e19b197278ae914->leave($__internal_adf4c3223cef5a1e40e467baf47a683b4a01b633869c6aa33e19b197278ae914_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "{% include '@Twig/Exception/error.xml.twig' %}
";
    }
}
