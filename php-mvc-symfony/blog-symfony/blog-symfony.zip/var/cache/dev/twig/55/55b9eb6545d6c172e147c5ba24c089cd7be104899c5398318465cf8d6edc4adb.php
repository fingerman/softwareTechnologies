<?php

/* @Twig/Exception/exception.js.twig */
class __TwigTemplate_a90369a55e552af8b6f01e19eae7138c9f2458e6d4cf85aa9d0d9b5b2fc7eb87 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9ebc4f5e37055d28d857756229b2010cac3672719a04c56b4f7f48c97e9a26fb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9ebc4f5e37055d28d857756229b2010cac3672719a04c56b4f7f48c97e9a26fb->enter($__internal_9ebc4f5e37055d28d857756229b2010cac3672719a04c56b4f7f48c97e9a26fb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "@Twig/Exception/exception.js.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_9ebc4f5e37055d28d857756229b2010cac3672719a04c56b4f7f48c97e9a26fb->leave($__internal_9ebc4f5e37055d28d857756229b2010cac3672719a04c56b4f7f48c97e9a26fb_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 3,  25 => 2,  22 => 1,);
    }

    public function getSource()
    {
        return "/*
{% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}
*/
";
    }
}
