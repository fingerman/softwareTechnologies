<?php

/* TwigBundle:Exception:exception.json.twig */
class __TwigTemplate_0c4e30c4fa62f96082c438ccc35b55b0ee592a04ac5895b4a2ccfac9dba53e43 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6844e6e11c25c5f341b72514b476e7d771053d42c4df96b53f6a4be6df835ee1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6844e6e11c25c5f341b72514b476e7d771053d42c4df96b53f6a4be6df835ee1->enter($__internal_6844e6e11c25c5f341b72514b476e7d771053d42c4df96b53f6a4be6df835ee1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "exception" => $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "toarray", array()))));
        echo "
";
        
        $__internal_6844e6e11c25c5f341b72514b476e7d771053d42c4df96b53f6a4be6df835ee1->leave($__internal_6844e6e11c25c5f341b72514b476e7d771053d42c4df96b53f6a4be6df835ee1_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "{{ { 'error': { 'code': status_code, 'message': status_text, 'exception': exception.toarray } }|json_encode|raw }}
";
    }
}
