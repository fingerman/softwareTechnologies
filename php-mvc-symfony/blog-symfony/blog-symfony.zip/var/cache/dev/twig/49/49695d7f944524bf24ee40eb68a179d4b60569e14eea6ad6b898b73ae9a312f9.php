<?php

/* @Twig/Exception/error.js.twig */
class __TwigTemplate_b17f0873a9ad6d21ed83ab6145092b67411ba8ca813fd89f68ef1b2b3e0a0fbe extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_68a38abdc1f686c966d6dd4f1e5c014ec67b2f4412ab43957dd4e623db761bc8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_68a38abdc1f686c966d6dd4f1e5c014ec67b2f4412ab43957dd4e623db761bc8->enter($__internal_68a38abdc1f686c966d6dd4f1e5c014ec67b2f4412ab43957dd4e623db761bc8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "js", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "js", null, true);
        echo "

*/
";
        
        $__internal_68a38abdc1f686c966d6dd4f1e5c014ec67b2f4412ab43957dd4e623db761bc8->leave($__internal_68a38abdc1f686c966d6dd4f1e5c014ec67b2f4412ab43957dd4e623db761bc8_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 2,  22 => 1,);
    }

    public function getSource()
    {
        return "/*
{{ status_code }} {{ status_text }}

*/
";
    }
}
