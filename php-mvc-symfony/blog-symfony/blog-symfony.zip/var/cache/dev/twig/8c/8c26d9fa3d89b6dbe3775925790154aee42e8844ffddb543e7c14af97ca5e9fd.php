<?php

/* @Framework/Form/datetime_widget.html.php */
class __TwigTemplate_ef48d9ef1f31e9087896b1ecf03054e8d3f2d14cde3ed002825f43ee03583bb2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_58ef45dda683a2560c9b3a4d64467ffb9e26156cd50b31a91b6d913269aed170 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_58ef45dda683a2560c9b3a4d64467ffb9e26156cd50b31a91b6d913269aed170->enter($__internal_58ef45dda683a2560c9b3a4d64467ffb9e26156cd50b31a91b6d913269aed170_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/datetime_widget.html.php"));

        // line 1
        echo "<?php if (\$widget == 'single_text'): ?>
    <?php echo \$view['form']->block(\$form, 'form_widget_simple'); ?>
<?php else: ?>
    <div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
        <?php echo \$view['form']->widget(\$form['date']).' '.\$view['form']->widget(\$form['time']) ?>
    </div>
<?php endif ?>
";
        
        $__internal_58ef45dda683a2560c9b3a4d64467ffb9e26156cd50b31a91b6d913269aed170->leave($__internal_58ef45dda683a2560c9b3a4d64467ffb9e26156cd50b31a91b6d913269aed170_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/datetime_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php if (\$widget == 'single_text'): ?>
    <?php echo \$view['form']->block(\$form, 'form_widget_simple'); ?>
<?php else: ?>
    <div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
        <?php echo \$view['form']->widget(\$form['date']).' '.\$view['form']->widget(\$form['time']) ?>
    </div>
<?php endif ?>
";
    }
}
