<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_3bed60fb0d21e968a3bcf4320c290ecbdd372cb981239eb23456f9283cf70476 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f02de6c1528d7527eba203b7cd0bd011b1e5bd3ccb14db0452ad24f927377eb6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f02de6c1528d7527eba203b7cd0bd011b1e5bd3ccb14db0452ad24f927377eb6->enter($__internal_f02de6c1528d7527eba203b7cd0bd011b1e5bd3ccb14db0452ad24f927377eb6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_f02de6c1528d7527eba203b7cd0bd011b1e5bd3ccb14db0452ad24f927377eb6->leave($__internal_f02de6c1528d7527eba203b7cd0bd011b1e5bd3ccb14db0452ad24f927377eb6_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    public function getSource()
    {
        return "";
    }
}
