<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_9de39fba48280b8c95dcab62d27941ae71b19d43ed4c493837b634e9c800bd89 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_934b2b321d1f7159645a0169e2a6f8f2f909702a40a557b2baf850d519fc8ca3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_934b2b321d1f7159645a0169e2a6f8f2f909702a40a557b2baf850d519fc8ca3->enter($__internal_934b2b321d1f7159645a0169e2a6f8f2f909702a40a557b2baf850d519fc8ca3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_934b2b321d1f7159645a0169e2a6f8f2f909702a40a557b2baf850d519fc8ca3->leave($__internal_934b2b321d1f7159645a0169e2a6f8f2f909702a40a557b2baf850d519fc8ca3_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
    }
}
